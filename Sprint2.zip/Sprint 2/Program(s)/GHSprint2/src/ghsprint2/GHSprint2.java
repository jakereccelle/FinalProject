package ghsprint2;
/**
 * @author mt13
 */
import java.io.File;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.nio.file.*;
import java.util.*;

public class GHSprint2 extends JFrame implements ActionListener
{
    static Scanner input;
    Path wordsPath = Paths.get("D:\\TERM 2\\PROJECT MANAGEMENT\\WEEK 10\\Flashcards\\words.txt");
    File wordsFile = new File("D:\\TERM 2\\PROJECT MANAGEMENT\\WEEK 10\\Flashcards\\words.txt");
    Path definitionsPath = Paths.get("D:\\TERM 2\\PROJECT MANAGEMENT\\WEEK 10\\Flashcards\\def.txt");
    File definitionsFile = new File("D:\\TERM 2\\PROJECT MANAGEMENT\\WEEK 10\\Flashcards\\def.txt");
    Container con = getContentPane();
    private JMenuItem saveAs;
    private JMenuBar main = new JMenuBar();
    private JMenu file = new JMenu("File");
    JLabel word = new JLabel(""); //placeholder to get results
    JLabel definition = new JLabel(""); //placeholder to get results
    JButton prev = new JButton("< Previous");
    JButton flip = new JButton("Flip");
    JButton next = new JButton("Next >");
    GridBagLayout layout = new GridBagLayout();
    String[] wordss = {"Fern", "Oak Tree", "Lilac", "Shameplant", 
        "Hydnellum Peckii", "Corpse Flower", "Baobab", "Sneezewort Yarrow", 
        "Turkey Corn", "Lambsquarters"};
    String[] definitionss = {"kind of looks like AAAAAAs", 
        "indistinguishable because it looks like every other tree", 
        "some kind of flower i dont know", 
        "the compound leaves fold inward and droop when touched or shaken, defending themselves from harm, and re-open a few minutes late", 
        "a special type of fungi that produce blood or juice like fluid on its surface. This plant is also known as ‘bleeding tooth fungus’. It is the Scarlet pigment causes blood like the color on the fluid of this plant", 
        "It is the largest branched main stem concern flowering plant in the world. The corpse flower is endemic to Sumatra. During flowering, the plant stands at 8.2 feet tall. The plant also produces the smell of decomposing animal", 
        "native to Madagascar, mainland Africa and Australia. Also known as the Bottle Tree, not only do they look like bottles, but the trees typically store around 300 liters of water!", 
        "a European species of herbaceous perennial flowering plant in the genus Achillea", 
        "flowering plant from eastern North America with oddly shaped white flowers and finely divided leaves", 
        "fast-growing weedy annual plant in the genus Chenopodium. Though cultivated in some regions, the plant is elsewhere considered a weed"};

    GHSprint2()
    {
        con.setLayout(layout);
        con.add(word);
        con.add(definition);
        setJMenuBar(main);
        main.add(file);
        file.add(saveAs);
        con.add(prev);
        con.add(flip);
        con.add(next);
        //action liseners for actions....
        prev.addActionListener(this);
        flip.addActionListener(this);
        next.addActionListener(this);
        
        word.setVisible(true);
        definition.setVisible(false);
       
        //setSize for setting size... size
        setSize(450, 250);
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        saveAs = new JMenuItem("Save As...");
        saveAs.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent arg0) {
                showSaveFileDialog();
            }
        });
    }
    private void showSaveFileDialog() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Specify a file to save");

        int userSelection = fileChooser.showSaveDialog(this);
        if (userSelection == JFileChooser.APPROVE_OPTION) {
            File fileToSave = fileChooser.getSelectedFile();
            System.out.println("Save as file: " + fileToSave.getAbsolutePath());
        }
    }
    
    public void fileReaderStuff()
    {
        String[] words = new String[10];
        String[] definitions = new String[10];
        String y = null;
        int x = 1;
        StringBuffer sb = new StringBuffer();

        try
        {   
            String s;
            InputStream input = new BufferedInputStream(Files.newInputStream(wordsPath));
            BufferedReader reader = new BufferedReader(new InputStreamReader(input));
            s = reader.readLine();
            while(s != null)
            {
                System.out.println(s);
                s = reader.readLine();   
            }

            for(int h = 0; h < words.length; h++)
                if(s.charAt(h) == ' ')
                    x++;
            reader.close();
        }
        catch(FileNotFoundException ex)
        {
            System.out.println(ex);
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) 
    {
        
        Object source = e.getSource();
        
        if(source == prev)
        {
            word.setVisible(true);
            definition.setVisible(false);
            switch(wordss.length)
            {
                case 1: 
                    word.setText(wordss[0]);
                break;
                case 2: 
                    word.setText(wordss[9]);
                break; 
                case 3: 
                    word.setText(wordss[8]);
                break;
                case 4: 
                    word.setText(wordss[7]);
                break;
                case 5: 
                    word.setText(wordss[6]);
                break;
                case 6: 
                    word.setText(wordss[5]);
                break;
                case 7: 
                    word.setText(wordss[4]);
                break;
                case 8: 
                    word.setText(wordss[3]);
                break;
                case 9: 
                    word.setText(wordss[2]);
                break;
                case 10: 
                    word.setText(wordss[1]);
                break;
                default:
                    word.setText(wordss[0]);
                break;     
            }
        }
        else if(source == flip)
        {
            word.setVisible(false);
            definition.setVisible(true);
            switch(definitionss.length)
            {
                case 1: 
                    definition.setText(definitionss[0]);
                break;
                case 2: 
                    definition.setText(definitionss[1]);
                break; 
                case 3: 
                    definition.setText(definitionss[2]);
                break;
                case 4: 
                    definition.setText(definitionss[3]);
                break;
                case 5: 
                    definition.setText(definitionss[4]);
                break;
                case 6: 
                    definition.setText(definitionss[5]);
                break;
                case 7: 
                    definition.setText(definitionss[6]);
                break;
                case 8: 
                    definition.setText(definitionss[7]);
                break;
                case 9: 
                    definition.setText(definitionss[8]);
                break;
                case 10: 
                    definition.setText(definitionss[9]);
                break;
                default:
                    definition.setText(definitionss[0]);
                break;
            }
        }
        else if(source == next)
        {
            word.setVisible(true);
            definition.setVisible(false);
            switch(wordss.length)
            {
                case 1: 
                    word.setText(wordss[0]);
                break;
                case 2: 
                    word.setText(wordss[1]);
                break; 
                case 3: 
                    word.setText(wordss[2]);
                break;
                case 4: 
                    word.setText(wordss[3]);
                break;
                case 5: 
                    word.setText(wordss[4]);
                break;
                case 6: 
                    word.setText(wordss[5]);
                break;
                case 7: 
                    word.setText(wordss[6]);
                break;
                case 8: 
                    word.setText(wordss[7]);
                break;
                case 9: 
                    word.setText(wordss[8]);
                break;
                case 10: 
                    word.setText(wordss[9]);
                break;
                default:
                    word.setText(wordss[0]);
                break;
            }
        }
        fileReaderStuff(); 
    }
    public static void main(String[] args)  
    {
        GHSprint2 frame = new GHSprint2();
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
        }

        SwingUtilities.invokeLater(new Runnable() {

            @Override
            public void run() {
                new GHSprint2();
            }
        });
    }

}