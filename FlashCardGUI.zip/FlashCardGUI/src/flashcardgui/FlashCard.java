
public class FlashCard

{

//Declare data members

private String qust;

private String ans;

// constructor of FlashCard()

public FlashCard()

{

qust = "";

ans = "";

}

// getNextQuestion() to retrieve the next question

public String getNextQuestion()

{

return qust;

}

// setNextQuestion() to set the next question

public void setNextQuestion(String qust)

{

this.qust = qust;

}

// getNextAnswer() to find the answer of the current question

public String getNextAnswer()

{

return ans;

}

// setNextAnswer() to set the answer

public void setNextAnswer(String ans)

{

this.ans = ans;

}

}
