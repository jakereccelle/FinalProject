import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.EtchedBorder;
import javax.swing.border.SoftBevelBorder;
import java.io.*;
import java.util.*;

public class FlashCardGUI extends JFrame implements ActionListener 
{
    
    JButton response;
    JLabel answerDisplay;
    ArrayList<FlashCard> QuestionsList;
    ArrayList<Boolean> bool;
    JPanel card, FlashCardGame;
    int count = 0;
    boolean flag = false;
    int index = 0;
    String welcome = "Welcome to Flash Card";
    String start = "START THE GAME";
    String nextQuestion = "Next Question";
    String answer = "Click for Answer";

    public FlashCardGUI() 
    {

        FlashCardGame = new JPanel(new BorderLayout());
        FlashCardGame.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(20, 20, 20, 20, Color.WHITE),
                BorderFactory.createRaisedSoftBevelBorder()));
        QuestionsList = new ArrayList<FlashCard>();
        bool = new ArrayList<Boolean>();
        card = new JPanel(new BorderLayout());
        response = new JButton(start);
        response.setFont(new Font("Courier New", Font.BOLD, 20));
        response.setBorder(BorderFactory.createSoftBevelBorder(
                SoftBevelBorder.RAISED, Color.DARK_GRAY, Color.BLUE));
        answerDisplay = new JLabel(welcome, SwingConstants.CENTER);
        answerDisplay.setFont(new Font("Courier New", Font.BOLD + Font.ITALIC, 16));
        card.add(answerDisplay, BorderLayout.CENTER);
        card.add(response, BorderLayout.SOUTH);
        FlashCardGame.add(card, BorderLayout.CENTER);
        add(FlashCardGame);
        response.addActionListener(this);
        readData();

    }

    public int getIndex() 
    {

        int random = 0;

        boolean f = false;
        while (!f) {
            random = (int) (Math.random() * bool.size());

            if (bool.get(random) == false) 
            {
                f = true;
                return random;
            }
        }

        return -1;

    }

    public void readData() 
    {
        File file = null;
       // File candy = null;
        //File chocolate = null;
        Scanner input = null;
        String question, answer;
        FlashCard obj = null;

        try 
        {
            //candy = new File("E:\\Proj Management\\final project\\a whole lot of bullshit\\FlashCardGUI\\words.txt");
            //chocolate = new File("E:\\Proj Management\\final project\\a whole lot of bullshit\\FlashCardGUI\\definitions.txt");
            file = new File("FlashQuestions.txt");
            input = new Scanner(file);
            while (input.hasNextLine()) {
                question = input.nextLine();
                answer = input.nextLine();
                obj = new FlashCard();
                obj.setNextQuestion(question);
                obj.setNextAnswer(answer);
                QuestionsList.add(obj);
                bool.add(false);
            }
            input.close();
        }
        catch (Exception exp) 
        {
            exp.printStackTrace();
        }

    }

    public void actionPerformed(ActionEvent event) 
    {
        if (event.getSource() == response) 
        {
            if (count < QuestionsList.size()) 
            {
                if (!flag) 
                {
                    index = getIndex();
                    response.setText(answer);
                    bool.set(index, true);
                    answerDisplay
                            .setText(QuestionsList.get(index).getNextQuestion());
                } 
                else 
                {
                    response.setText(nextQuestion);
                    answerDisplay.setText(QuestionsList.get(index).getNextAnswer());
                    count++;

                }
                flag = !flag;

            } 
            else {

                int repeat = JOptionPane
                        .showConfirmDialog(
                                null,
                                "Would you like to go through the questions again? ",
                                "Confirmation",
                                JOptionPane.YES_NO_OPTION);

                if (repeat == JOptionPane.YES_OPTION) {
                    response.setText(start);
                    answerDisplay.setText(welcome);
                    count = 0;
                    QuestionsList = new ArrayList<FlashCard>();
                    bool = new ArrayList<Boolean>();
                    readData();
                    flag = false;
                } 
                else 
                {
                    answerDisplay.setText("Thanks for learning few general knowledge questions!");
                    response.setEnabled(false);
                }
            }
        }
    }

    public static void main(String args[]) 
    {
        FlashCardGUI game = new FlashCardGUI();
        game.setTitle("Flash Card Game");
        game.setSize(1000, 500);
        game.setResizable(false);
        game.setVisible(true);
        game.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    }

}
