package githubfinalproject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.Scanner;

public class GithubFinalProject {

    public static void main(String[] args) throws IOException {
        String filePath = ("D:\\TERM 2\\PROJECT MANAGEMENT\\WEEK 10\\Flashcards\\cardRead.txt");
        Scanner input = new Scanner(System.in);
        String enter;
        FileReader fileReader = new FileReader(filePath);
        BufferedReader br = new BufferedReader(fileReader);
        StringBuffer sb = new StringBuffer();
        String line;

        while ((line = br.readLine()) != null) {
            //if(user input == true){} - - - ??? is this even possible?
            System.out.println("Next: Enter Key");
            enter = input.nextLine();

            sb.append(line);
            System.out.println(line);
            //sb.append("\n");
        }
        fileReader.close();
        //System.out.println(sb.toString());
    }
}
